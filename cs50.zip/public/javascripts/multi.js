let me;
let adversaire;
let theTime;
let time;
let time2;
let mySnake = [];
let hisSnake = [];
let height = 15;
let width = 20;
let myColor;
let myBodyColor;
let hisColor;
let hisBodyColor;
let speed = 350;
let dir = 38;
let olddir = 38;
let rivalPos;
let ws;
let wkey;
let toeat = [];
let no;
let start = false;
let myName;
let hisName;
let restrt = false;

generategrid();

initws();



function startgame(){
    clearTimeout(time);
    start = true;
    time = setInterval(game, speed);
    return;
}


function initws(){
    if (ws) {
      ws.onerror = ws.onopen = ws.onclose = null;
      ws.close();
    }
    ws = new WebSocket('ws://'+window.location.host);
    ws.onopen = function () {
        console.error('WebSocket connection established');
        ws.send("connected");
    };
    ws.onmessage = function({data}) {
        if(parseInt(data,10) && start === true){
            cutting(parseInt(data,10));
            move(parseInt(data,10), hisSnake , mySnake, hisColor, hisBodyColor, myColor);     
        }

        else if (/^n/i.test(data)){
            food(parseInt(data.replace('n', ''),10));
        }

        else if (data === 'player1' || data === 'player2'){
            no = data
            console.error('no= ' + no);
            initgame(no);
            getname();
            ws.send('ready');
        }

        else if (data === 'decount'){
            score();
            console.log('game start in 3 sec');
            time = setTimeout(startgame, 3000);
            gametime();
            if(myColor == 'red'){
                foodgenerator();
            }
        }

        else if (data === 'adv left'){
            ws.close();
            clearInterval(theTime);
            clearInterval(time);
            clearInterval(time2);
            document.getElementById('haveleftmsg').style.display = 'block';
        }

        else if (/machin/i.test(data)){
            restrt = true;
            data = data.replace('machin', hisName);
            console.error(data);
            document.getElementById('leavemsg').innerHTML = data;
            document.getElementById('leavemsg').style.display = 'block';
        }

        else if(data === 'wait'){
            wait();
        }
    };
        
    ws.onclose = function () {
        console.error('WebSocket connection closed');
        ws = null;
    };    
};


function game(){
    let newpos;
    olddir = dir;
    switch(dir){
        case 38:
            newpos = mySnake[0]-width;
            break;
        case 40:
            newpos = mySnake[0]+width;
            break;
        case 37:
            newpos = mySnake[0]-1;
            break;
        case 39:
            newpos = mySnake[0]+1;
    }
    if(newpos < 0){
        newpos += width*height;
    }
    if(newpos > width*height-1){
        newpos -= width*height;
    }
    if(newpos%width == width-1 && dir == 37){
        newpos += width
    }
    if(newpos%width == 0 && dir == 39){
        newpos -= width
    }
    ws.send(newpos.toString());
    cutting(newpos);
    return move(newpos, mySnake, hisSnake, myColor, myBodyColor, hisColor);
}


function move(newpos, snake1, snake2, color, mbcolor, hcolor){
    if (mySnake.length == 0 || hisSnake.length == 0){
        console.error('end');
        return theend();
    }

    if(newpos == snake2[0]){
        snake2.shift();
        if(snake2[0]){
            document.getElementById(snake2[0]).style.backgroundColor = hcolor;
        }
        score();
    }

    if (toeat.includes(snake1[0])){
        toeat.splice(toeat.indexOf((snake1[0])),1);
    }
    else{
        let lastpos = snake1.pop();
        document.getElementById(lastpos).style.backgroundColor = "#EEEEEE";
    }
    snake1.unshift(newpos);
    score();
    document.getElementById(newpos).style.backgroundColor = color;
    if (snake1[1]){
        document.getElementById(snake1[1]).style.backgroundColor = mbcolor;
    }
    
}


function cutting(pos){

    if (mySnake.includes(pos) && mySnake.indexOf(pos) != 0){
        let moreFood = mySnake.splice(mySnake.indexOf(pos));
        for (newFood of moreFood){
            food(newFood);
        }
    }
    if (hisSnake.includes(pos) && hisSnake.indexOf(pos) != 0){
        let moreFood = hisSnake.splice(hisSnake.indexOf(pos));
        for (newFood of moreFood){
            food(newFood);
        }
    }
}



function initgame(no){
    if (no == 'player1'){
        myColor = 'blue';
        myBodyColor = '#5555FF';
        hisColor = 'red';
        hisBodyColor = '#FF5555';
        mySnake.push(Math.floor(height*width/2 + width/3));
        hisSnake.push(Math.floor(height*width/2 + 2*width/3));
    }
    else{
        hisColor = 'blue';
        hisBodyColor = '#5555FF';
        myColor = 'red';
        myBodyColor = '#FF5555';
        hisSnake.push(Math.floor(height*width/2 + width/3));
        mySnake.push(Math.floor(height*width/2 + 2*width/3));
    }
    for(let i = 0; i < 5; i++){
        if (i == 0){
            document.getElementById(mySnake[0]+i*width).style.backgroundColor = myColor;
            document.getElementById(hisSnake[0]+i*width).style.backgroundColor = hisColor;            
        }
        if (i > 0){
            document.getElementById(mySnake[0]+i*width).style.backgroundColor = myBodyColor;
            document.getElementById(hisSnake[0]+i*width).style.backgroundColor = hisBodyColor;            
            mySnake.push(mySnake[0]+i*width);
            hisSnake.push(hisSnake[0]+i*width);
        }
    }
    
}


function food(newFood){
    
    if(!newFood || !Number.isInteger(newFood)){
        console.error(newFood);
    }
    else{
        toeat.push(newFood);
        document.getElementById(newFood).style.backgroundColor = 'green';
    }
    
}


function foodgenerator(){
    time2 = setInterval(function(){
        let rdm = Math.floor(Math.random() * width*height-1);
        if(!mySnake.includes(rdm) && !hisSnake.includes(rdm) && !toeat.includes(rdm)){
            food(rdm);
            ws.send('n'+rdm.toString())
        }
    },767);
}


function generategrid(){
    let mainElement = document.getElementById('main')
    for (let i = 0; i < height; i++){
        
        let row = document.createElement("div");
        row.setAttribute('class','row');
        mainElement.appendChild(row);

        for (let j = 0; j < width; j++){

            let column = document.createElement("div");
            column.setAttribute('id', (i*width + j).toString());
            column.setAttribute('class','column');
            row.appendChild(column);

        }
    }
    mainElement.style.width = (100*height/width).toString() + 'vh';                         //(90*width/height).toString() + 'vh'
    mainElement.style.height = (80*height/width).toString() + 'vh';
    row = document.getElementsByClassName('row');
    column = document.getElementsByClassName('column');
    for (e of row){
        e.style.height = (100/height).toString() + '%';
    }
    for (e of column){
        e.style.width = (100/width).toString() + '%';
    }
}


function listenKey(e){
    let d = keycode(e);
    if (d == olddir + 2 || d == olddir - 2){
        //do nothing
    }
    else if (d > 36 && d < 41){
        dir = d;
    }
}


function keycode(e){
    if (e == 'ArrowUp'){
        return 38;
    }
    if (e == 'ArrowDown'){
        return 40;
    }
    if (e == 'ArrowLeft'){
        return 37;
    }
    if (e == 'ArrowRight'){
        return 39;
    }
}


window.addEventListener('keydown', function(e){
    wkey = e.key;
    listenKey(wkey);
});



function getname(){
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200){
            let names =  xhttp.responseText.split(',');
            myName = names[0];
            hisName = names[1];
            document.getElementById('me').textContent =  names[0];
            document.getElementById('me').style.color = myColor;
            document.getElementById('him').textContent = names[1];
            document.getElementById('him').style.color = hisColor;
        }
    }
    xhttp.open("GET", "/multi/names", true);
    xhttp.send();
}


function gametime(){
    let decount = 3;
    let gtime = 30;
    theTime = setInterval(function(){
        decount --;
        if (decount + gtime > gtime)
            document.getElementById('time').textContent = (decount).toString();
        if (decount + gtime == gtime)
            document.getElementById('time').textContent = 'START';
        if (decount + gtime < gtime-1)
            document.getElementById('time').textContent = (decount+gtime).toString();
        if (decount + gtime < 0){
            document.getElementById('time').textContent = 'The End';
            theend();
        }
    },1000);
}


function score(){
    document.getElementById('sme').textContent = mySnake.length.toString();
    document.getElementById('shim').textContent = hisSnake.length.toString();
}


function theend(){
    clearInterval(theTime);
    clearInterval(time);
    clearInterval(time2);
    start = false;
    ws.send('readynot');

    if (mySnake.length > hisSnake.length){
        document.getElementById('me').textContent += ' WON !';
    }
    else if (mySnake.length == hisSnake.length){
        document.getElementById('leavemsg').textContent = 'ex aequo';
    }

    else{
        document.getElementById('him').textContent += ' WON !';
    }
    
    document.getElementById('restart').style.display = 'block';
}


function restart(){
    if(restrt === false){
        ws.send('restart');
    }
    ws.send('ready');
    restrt = false;
    for (let i = 0; i < width*height-1; i++){
        document.getElementById(i).style.backgroundColor = "#EEEEEE";
    }
    document.getElementById('me').textContent = myName;
    document.getElementById('him').textContent = hisName;
    document.getElementById('restart').style.display = 'none';
    document.getElementById('leavemsg').style.display = 'none';
    mySnake = [];
    hisSnake = [];
    toeat = [];
    dir = 38;
    olddir = 38;

    initgame(no);
}


function wait(){
    let time  = setTimeout(function() {
        ws.send("connected");
        clearTimeout(time);
    }, 1000);
}



/*
function askifrdy(){
    time = setTimeout(function(){
        let xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200 && xhttp.responseText == 'rdy') {
                document.getElementById('rdy2').style.color = 'green';
                listenKey()
                time = setInterval(game,speed);
                return;
            }
            else if (this.readyState == 4 && this.status == 200 && xhttp.responseText == 'nok')
                return askifrdy();
        };
        xhttp.open("GET", "/statuscheck", true);
        xhttp.send();
    },2000);
}

// when close rmv db;


*/

