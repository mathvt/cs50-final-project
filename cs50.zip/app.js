var createError = require('http-errors');
var express = require('express');
var http = require('http');
var path = require('path');
var cookieParser = require('cookie-parser');
var cookie = require('cookie');
var logger = require('morgan');
const session = require('express-session');
const bodyParser = require('body-parser');

const sessionParser = session({
  saveUninitialized: false,
  secret: 'onix',
  resave: false
});

var indexRouter = require('./routes/index');
var multiRouter = require('./routes/multisnake');
var soloRouter = require('./routes/solosnake');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(sessionParser);


const WebSocket = require('ws');
const { request } = require('express');
const wss = new WebSocket.Server({ clientTracking: true, noServer: true });
const server = http.createServer(app);


app.use('/', indexRouter.router);
app.use('/multi', multiRouter);
app.use('/solo', soloRouter);

var players = indexRouter.players;

var clients = {};


wss.clients.forEach(function each(ws) {
  return ws.terminate();
});

server.on('upgrade', function upgrade(req, socket, head) {
  sessionParser(req, {}, () => {
    if (!req.session.name) {
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      socket.destroy();
      return;
    }
    wss.handleUpgrade(req, socket, head, function (ws) {
      wss.emit('connection', ws, req);
    });
  });
});

wss.on('connection', function connection(ws, req) {
  connectedtows(req.session.name, ws);
  ws.on('message', function message(msg) {

    if (parseInt(msg,10)){
      if (clients[req.session.adversaire] != null)
        clients[req.session.adversaire].ws.send(msg);
        else{
          clients[req.session.name].ws.send('adv left');
          clients[req.session.name] = null;
        }
    }

    else if (/^n/i.test(msg) && clients[req.session.adversaire]){
      clients[req.session.adversaire].ws.send(msg);
  }
  
    else if (msg === 'connected'){
      if (!clients[req.session.adversaire])
        ws.send('wait')
      else
        ifconnectedok(req.session.name, req.session.adversaire);
    }

    else if (msg === 'ready' && clients[req.session.adversaire]){
      aplayerisready(req.session.name, req.session.adversaire);
    }

    else if (msg === 'readynot' && clients[req.session.adversaire]){
      clients[req.session.name].status = 'not rdy';
      console.error(req.session.name +' is '+ clients[req.session.name].status)
    }

    else if (msg === 'restart' && clients[req.session.adversaire]){
      clients[req.session.adversaire].ws.send('machin want to play again !');
    }

    ws.on('close', function () {
      if (clients[req.session.adversaire]){
        clients[req.session.adversaire].ws.send('adv left');
      }
      if(players.indexOf(req.session.name) != -1){
        console.log(players.splice(players.indexOf(req.session.name),1)+' removed');
        console.log(players)
      }
      clients[req.session.name] = null;
    });
  });
});







// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

// my functions ###############################################

function connectedtows(name, ws){
  clients[name] = {};
  clients[name].ws = ws;
  clients[name].numero = null;
  clients[name].status = 'not rdy';
}


function ifconnectedok(name, adv){
  console.error(name+'     '+adv)
  if(clients[name].numero === null){
    clients[name].numero = 'player1';
    clients[adv].numero = 'player2';
    clients[name].ws.send(clients[name].numero);
  }
  else{
    clients[name].ws.send(clients[name].numero);
  }
}


function aplayerisready(name, adv){
  console.error(name + ' is ready')
  clients[name].status ='rdy';
  if(clients[adv].status === 'rdy'){
    clients[name].ws.send('decount');
    clients[adv].ws.send('decount');
  }
}



module.exports = {app:app, server:server};
